//
//  BotAppApp.swift
//  BotApp
//
//  Created by Ahmed Salah on 01/09/2022.
//

import SwiftUI

@main
struct BotAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
