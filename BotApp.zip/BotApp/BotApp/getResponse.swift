//
//  getResponse.swift
//  BotApp
//
//  Created by Ahmed Salah on 01/09/2022.
//

import Foundation



func getBotResponce(message: String) -> String {
    
    
    let tempMessage = message.lowercased()
    
    if tempMessage.contains("مرحبا") {
        return "مرحبا احمد"
    } else if tempMessage.contains("كيف حالك") {
        return "انا بخير والحمد لله"
    } else if tempMessage.contains("انتبة على نفسك") {
        return "شكرا على سؤالك"
    } else {
        return "Ok"
    }
    
    
}


